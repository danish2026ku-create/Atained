# Atained

**Atained** is a premium, local-first Android productivity app for goals, tasks, habits, focus and personal insights. Built from scratch with Kotlin and Jetpack Compose.

## Features
- Unified “Today” dashboard with daily momentum
- Habit tracking and streaks
- Task planning and quick-add flow
- Goal progress cards
- Functional Pomodoro focus timer
- Weekly insights and performance highlights
- Dark mode based on system preference
- Edge-to-edge Material 3 design

## Run
1. Open this folder in Android Studio Ladybug or newer.
2. Use JDK 17 and let Gradle sync.
3. Run the `app` configuration on Android 8.0+.

Command line (after generating/using the Gradle wrapper): `./gradlew assembleDebug`

## Product direction
Recommended next steps: Room persistence, notification scheduling, home-screen widgets, cloud sync, authentication, localization (Hindi/English), accessibility tests, and Play Store release signing.
