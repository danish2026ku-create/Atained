package com.atained.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.atained.app.ui.theme.AtainedTheme
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent { AtainedTheme { AtainedApp() } } }
}

data class Task(val id:Int,val title:String,val category:String,val time:String,var done:Boolean=false)
data class Habit(val id:Int,val title:String,val icon:String,val streak:Int,var done:Boolean=false)
data class Goal(val id:Int,val title:String,val progress:Float,val due:String,val color:Color)

class AtainedViewModel: ViewModel() {
    var tasks by mutableStateOf(listOf(Task(1,"Finish product proposal","Work","10:30 AM"),Task(2,"Read 20 pages","Growth","6:00 PM"),Task(3,"Plan tomorrow","Personal","9:00 PM")))
    var habits by mutableStateOf(listOf(Habit(1,"Morning meditation","☀",12),Habit(2,"Drink 8 glasses","💧",8),Habit(3,"Daily movement","⚡",21)))
    val goals = listOf(Goal(1,"Launch my side project",.72f,"18 days left",Color(0xFF6857E5)),Goal(2,"Complete 24 books",.54f,"11 of 24",Color(0xFF22A699)),Goal(3,"Run 500 km",.38f,"190 km",Color(0xFFEF8354)))
    fun toggleTask(id:Int){ tasks=tasks.map{if(it.id==id)it.copy(done=!it.done)else it} }
    fun toggleHabit(id:Int){ habits=habits.map{if(it.id==id)it.copy(done=!it.done)else it} }
    fun addTask(title:String){ tasks=tasks+Task((tasks.maxOfOrNull{it.id}?:0)+1,title,"Personal","Today") }
}

enum class Tab(val label:String,val icon:ImageVector){Today("Today",Icons.Outlined.Home),Plan("Plan",Icons.Outlined.CheckCircle),Focus("Focus",Icons.Outlined.Timer),Insights("Insights",Icons.Outlined.BarChart),Profile("You",Icons.Outlined.Person)}

@Composable fun AtainedApp(vm:AtainedViewModel= viewModel()){
    var tab by remember{mutableStateOf(Tab.Today)}; var add by remember{mutableStateOf(false)}
    Scaffold(
        bottomBar={ NavigationBar(containerColor=MaterialTheme.colorScheme.surface){Tab.entries.forEach{ NavigationBarItem(selected=tab==it,onClick={tab=it},icon={Icon(it.icon,null)},label={Text(it.label)}) }}},
        floatingActionButton={if(tab==Tab.Today||tab==Tab.Plan) FloatingActionButton(onClick={add=true},shape=CircleShape){Icon(Icons.Default.Add,"Add")}}
    ){pad-> Box(Modifier.padding(pad).fillMaxSize()){ AnimatedContent(tab,label="tabs"){when(it){Tab.Today->TodayScreen(vm);Tab.Plan->PlanScreen(vm);Tab.Focus->FocusScreen();Tab.Insights->InsightsScreen();Tab.Profile->ProfileScreen()}} } }
    if(add) AddTaskDialog(onDismiss={add=false},onAdd={vm.addTask(it);add=false})
}

@Composable fun Page(modifier:Modifier=Modifier, content: LazyListScope.()->Unit)= LazyColumn(modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp),content=content)
@Composable fun Header(kicker:String,title:String,action:ImageVector?=null){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1)){Text(kicker,style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.primary);Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold)};action?.let{FilledTonalIconButton(onClick={}){Icon(it,null)}}}}
@Composable fun SectionTitle(title:String,action:String?=null){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(title,fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1));action?.let{Text(it,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.SemiBold)}}}
@Composable fun SoftCard(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit)=Card(modifier,shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),elevation=CardDefaults.cardElevation(1.dp),content=content)

@Composable fun TodayScreen(vm:AtainedViewModel){
    val date=remember{LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d"))}
    Page{item{Header(date,"Good morning, Alex",Icons.Outlined.Notifications)}
        item{MomentumCard(vm)}
        item{SectionTitle("Today’s habits","${vm.habits.count{it.done}}/${vm.habits.size}")}
        items(vm.habits,key={it.id}){HabitRow(it){vm.toggleHabit(it.id)}}
        item{SectionTitle("Priority tasks","See all")}
        items(vm.tasks.take(3),key={it.id}){TaskRow(it){vm.toggleTask(it.id)}}
        item{Spacer(Modifier.height(70.dp))}
    }
}
@Composable fun MomentumCard(vm:AtainedViewModel){val total=vm.tasks.size+vm.habits.size;val done=vm.tasks.count{it.done}+vm.habits.count{it.done};val p=if(total==0)0f else done.toFloat()/total
    SoftCard(Modifier.fillMaxWidth()){Box(Modifier.background(MaterialTheme.colorScheme.primary).padding(22.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1)){Text("DAILY MOMENTUM",color=Color.White.copy(.75f),fontWeight=FontWeight.Bold,fontSize=12.sp);Spacer(Modifier.height(8.dp));Text(if(done==0)"Make today count" else "You’re on a roll!",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold);Text("Complete one small win at a time.",color=Color.White.copy(.8f))};Box(contentAlignment=Alignment.Center){CircularProgressIndicator(progress={p},modifier=Modifier.size(76.dp),color=Color.White,trackColor=Color.White.copy(.22f),strokeWidth=8.dp);Text("${(p*100).toInt()}%",color=Color.White,fontWeight=FontWeight.Bold)}}}}}
@Composable fun HabitRow(h:Habit,onClick:()->Unit){SoftCard(Modifier.fillMaxWidth().clickable(onClick=onClick)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),contentAlignment=Alignment.Center){Text(h.icon,fontSize=22.sp)};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1)){Text(h.title,fontWeight=FontWeight.SemiBold);Text("🔥 ${h.streak} day streak",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Icon(if(h.done)Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,null,tint=if(h.done)MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline)}}}
@Composable fun TaskRow(t:Task,onClick:()->Unit){SoftCard(Modifier.fillMaxWidth().clickable(onClick=onClick)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(t.done)Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,null,tint=if(t.done)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline);Spacer(Modifier.width(14.dp));Column(Modifier.weight(1)){Text(t.title,fontWeight=FontWeight.SemiBold,color=if(t.done)MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface);Text("${t.category}  •  ${t.time}",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Icon(Icons.Outlined.MoreVert,null)}}}

@Composable fun PlanScreen(vm:AtainedViewModel){Page{item{Header("YOUR COMMAND CENTER","Plan & achieve")};item{SectionTitle("Active goals","${vm.goals.size} goals")};items(vm.goals){GoalCard(it)};item{SectionTitle("All tasks","${vm.tasks.count{!it.done}} remaining")};items(vm.tasks){TaskRow(it){vm.toggleTask(it.id)}};item{Spacer(Modifier.height(70.dp))}}}
@Composable fun GoalCard(g:Goal){SoftCard(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Row{Box(Modifier.size(12.dp).clip(CircleShape).background(g.color));Spacer(Modifier.width(10.dp));Text(g.title,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1));Text("${(g.progress*100).toInt()}%",color=g.color,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(14.dp));LinearProgressIndicator(progress={g.progress},modifier=Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),color=g.color,trackColor=g.color.copy(.14f));Spacer(Modifier.height(8.dp));Text(g.due,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

@Composable fun FocusScreen(){var seconds by remember{mutableIntStateOf(25*60)};var running by remember{mutableStateOf(false)};LaunchedEffect(running,seconds){if(running&&seconds>0){delay(1000);seconds--}else if(seconds==0)running=false};val p=seconds/(25f*60f)
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Header("DEEP WORK","Focus sanctuary");Spacer(Modifier.weight(.5f));Box(Modifier.size(260.dp),contentAlignment=Alignment.Center){Canvas(Modifier.fillMaxSize()){drawArc(Color(0xFFE8E5FF),-90f,360f,false,style=Stroke(18.dp.toPx(),cap=StrokeCap.Round));drawArc(Color(0xFF6857E5),-90f,360f*p,false,style=Stroke(18.dp.toPx(),cap=StrokeCap.Round))};Column(horizontalAlignment=Alignment.CenterHorizontally){Text("%02d:%02d".format(seconds/60,seconds%60),fontSize=54.sp,fontWeight=FontWeight.Bold);Text("FOCUS SESSION",letterSpacing=2.sp,color=MaterialTheme.colorScheme.primary)}};Spacer(Modifier.height(38.dp));Button(onClick={running=!running},modifier=Modifier.height(58.dp).width(180.dp),shape=RoundedCornerShape(18.dp)){Icon(if(running)Icons.Default.Pause else Icons.Default.PlayArrow,null);Spacer(Modifier.width(8.dp));Text(if(running)"Pause" else "Begin focus",fontWeight=FontWeight.Bold)};TextButton(onClick={running=false;seconds=25*60}){Text("Reset")};Spacer(Modifier.weight(1f));Text("Put your attention where your intention is.",textAlign=TextAlign.Center,color=MaterialTheme.colorScheme.onSurfaceVariant)} }

@Composable fun InsightsScreen(){Page{item{Header("YOUR PROGRESS","Insights")};item{SoftCard(Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp)){Text("Weekly consistency",fontWeight=FontWeight.Bold);Text("82%",fontSize=42.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text("↑ 12% from last week",color=MaterialTheme.colorScheme.tertiary)}}};item{SectionTitle("This week")};item{WeekChart()};item{SectionTitle("Highlights")};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){Metric("21","day streak",Icons.Outlined.LocalFireDepartment,Modifier.weight(1f));Metric("14","tasks done",Icons.Outlined.TaskAlt,Modifier.weight(1f))}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){Metric("6.5h","focused",Icons.Outlined.Timer,Modifier.weight(1f));Metric("3","goals moved",Icons.Outlined.Flag,Modifier.weight(1f))}}}}
@Composable fun WeekChart(){val vals=listOf(.45f,.7f,.55f,.88f,.66f,.92f,.4f);SoftCard(Modifier.fillMaxWidth()){Row(Modifier.height(190.dp).padding(20.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.Bottom){vals.forEachIndexed{i,v->Column(horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.width(22.dp).height((120*v).dp).clip(RoundedCornerShape(8.dp)).background(if(i==5)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer));Text("MTWTFSS"[i].toString(),fontSize=12.sp,modifier=Modifier.padding(top=8.dp))}}}}}
@Composable fun Metric(value:String,label:String,icon:ImageVector,modifier:Modifier=Modifier){SoftCard(modifier){Column(Modifier.padding(18.dp)){Icon(icon,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(12.dp));Text(value,fontSize=25.sp,fontWeight=FontWeight.Bold);Text(label,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

@Composable fun ProfileScreen(){Page{item{Header("MAKE IT YOURS","Your space")};item{Column(Modifier.fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(92.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),contentAlignment=Alignment.Center){Text("A",fontSize=40.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)};Text("Alex Morgan",fontSize=24.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));Text("Building a life with intention",color=MaterialTheme.colorScheme.onSurfaceVariant)}};item{SectionTitle("Atained level")};item{SoftCard(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("Level 8 · Momentum Maker",fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));LinearProgressIndicator(progress={.68f},Modifier.fillMaxWidth().height(8.dp).clip(CircleShape));Text("680 / 1000 XP",fontSize=12.sp,modifier=Modifier.padding(top=6.dp))}}};item{SectionTitle("Preferences")};items(listOf(Triple("Appearance",Icons.Outlined.DarkMode,"System"),Triple("Reminders",Icons.Outlined.Notifications,"On"),Triple("Data & privacy",Icons.Outlined.Lock,"Local first"),Triple("About Atained",Icons.Outlined.Info,"v1.0.0"))){s->SoftCard(Modifier.fillMaxWidth()){Row(Modifier.padding(17.dp),verticalAlignment=Alignment.CenterVertically){Icon(s.second,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.width(14.dp));Text(s.first,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);Text(s.third,color=MaterialTheme.colorScheme.onSurfaceVariant);Icon(Icons.Default.ChevronRight,null)}}}}}

@Composable fun AddTaskDialog(onDismiss:()->Unit,onAdd:(String)->Unit){var title by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,icon={Icon(Icons.Outlined.AddTask,null)},title={Text("Create a new task")},text={OutlinedTextField(title,{title=it},label={Text("What needs to be done?")},singleLine=true)},confirmButton={Button(onClick={if(title.isNotBlank())onAdd(title.trim())},enabled=title.isNotBlank()){Text("Add task")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}
