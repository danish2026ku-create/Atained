package com.atained.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF6558D9), onPrimary = Color.White,
    primaryContainer = Color(0xFFE8E5FF), onPrimaryContainer = Color(0xFF211A5C),
    secondary = Color(0xFFEF8354), tertiary = Color(0xFF22A699),
    background = Color(0xFFF8F7FC), surface = Color.White,
    surfaceVariant = Color(0xFFF0EEF6), onSurface = Color(0xFF1D1B20)
)
private val Dark = darkColorScheme(
    primary = Color(0xFFC7C1FF), onPrimary = Color(0xFF302775),
    primaryContainer = Color(0xFF463D91), secondary = Color(0xFFFFB596), tertiary = Color(0xFF72D7CB),
    background = Color(0xFF121116), surface = Color(0xFF1B1A20), surfaceVariant = Color(0xFF29272F)
)
@Composable fun AtainedTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, typography = Typography(), content = content)
}
